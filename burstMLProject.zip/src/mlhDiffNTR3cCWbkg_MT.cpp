/* BurstML1 maximum likelihood method with n-state linear kinetic model for 3-color CW data (DA1A2 + DA1 + DA2 + D-only)
   There are 10n+8 fitting parameters: {total n*(numSp + 6) + numSp + 2*numC - 2}, numSp = 2^(numC - 1)
   if numC = 3, parameters 1 to 3n: count rate, n0(1) ~ n0(n), DA1A2, DA1, DA2
				parameters 3n+1: count rate D-only, {total n*(numSp-1) + 1}
				parameters 3n+2 to 4n+1: diffusion time, tau(1) ~ tau(n); {total n parameter}
				parameters 4n+2 to 5n: k(1) ~ k(n-1), k(1) is the sum of foward and backward rates between state 1 and 2; {total n-1}
				parameters 5n+1 to 6n-1: f(1) ~ f(n-1), p(1) = f(1), p(2) = [1-f(1)]*f(2), p(3) = [1-f(1)]*[1-f(2)]*f(3), ...
				p(n) = [1-f(1)]*[1-f(2)]* ... *[1-f(n-1)].
				Instead of population p, a relative fraction f is used. f(i) = p(i)/(p(i)+p(i+1). Each f ranges from 0 to 1. {total n-1}
				parameters 6n to 6n+2: fsp(1) ~ fsp(3), fraction parameters of DA1A2, DA1, DA2 (same format as p above) {total numSp-1}
				parameters 6n+3 to 8n+2: A1, A2 fraction for DA1A2, e1(1) ~ e1(n), e2(1) ~ e2(n) 
				parameters 8n+3 to 9n+2: A1+A2 fraction for DA1, E1(1) ~ E1(n)
				parameters 9n+3 to 10n+2: A2 fraction for DA2, E2(1) ~ E2(n)  {total 4*n}, work only for 3 color
				parameters 10n+3 to 10n+4: A1 and A2 bkg for d-only, e1, e2  {total numC-1}
				parameters 10n+5: A1 leak into A2 (= A2/[A1+A2]), note leak parameters are numC combination 2 (3 for 3 color)
				parameters 10n+6 to 10n+8: bkg cnt (A1, A2, D) {total numC} */

#include "mlhDiffNTR3cCWbkg_MT.h"

/* Customization starts */
bool ratemat0_init(gsl_matrix* ratemat0, const gsl_vector* peq, const double ratesum)
// initialize the ratematrix using p_eq and ratesum
{
	gsl_matrix_set(ratemat0, 0, 0, -gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 0, 1, gsl_vector_get(peq, 0));
	gsl_matrix_set(ratemat0, 1, 0, gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 1, 1, -gsl_vector_get(peq, 0));
	gsl_matrix_scale(ratemat0, ratesum);
	return false;
}

/* The gateway function */
//DLL_EXPORT_SYM  // for versions 2018b and earlier
MEXFUNCTION_LINKAGE // for Matlab 2019b
void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
{
	//Set higher priority to the process
	SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);

	switch(nrhs) 
	{
		case 7: //
		{
			//MATLAB variables
			c_data *input_data=new c_data;

			if (input_from_matlab(prhs, input_data)) //assign c_data using MATLAB input prhs
			{
				mexErrMsgTxt("Error: input parameters are inconsistent!");
				return;
			}

			/* Customization starts */
			input_data->number_of_colors = mwSize(input_data->numcolor[0]);
			input_data->number_of_species = pow(2, input_data->number_of_colors - 1);	//DA1A2, DA1, DA2, D-only
			input_data->number_of_states = (input_data->number_of_parameters + 2 - 2 * input_data->number_of_colors - input_data->number_of_species) 
											/ (6 + input_data->number_of_species);
			
			/* Customization ends*/

			gsl_vector * output_data;
			if (input_data->number_of_evaluations > 2)
			{
				output_data = calc_mlh_sub(input_data);
				output_to_matlab(output_data, plhs);
			}
			else
			{
				if (input_data->number_of_evaluations == 2) {
					input_data->number_of_evaluations = 1;
					output_data = calc_mlh_sub(input_data);
					output_to_matlab(output_data, plhs);
				}
				else {
					output_data = calc_mlh(input_data);
					output_to_matlab(output_data, plhs);
				}
			}

			//free variables
			input_data_free(input_data);
			gsl_vector_free(output_data);
		}break;

		default:
		{
			mexErrMsgTxt("Error: number of input args should be 7!");
		}
	}
	return;
}

/* Main routines */
unsigned __stdcall analysisThread(void *param)
{
	mt_vars* mt_param = (mt_vars*)param;
	c_data *input_data = mt_param->input_data;
	mlh_vars *m_vars = mt_param->m_vars;

	int cursor = mt_param->curThread;

	//mexPrintf("Thread %d invoked\n", cursor);

	mwSize numC = input_data->number_of_colors;
	mwSize numSt = input_data->number_of_states;
	mwSize numSp = input_data->number_of_species;
	mwSize numP = input_data->number_of_parameters;
	mwSize numS = input_data->number_of_coords;
	mwSize numS2 = numSt * numS;
	double *diffparams = input_data->diffparams;

	mwSize numPn0 = numSt * (numSp - 1) + 1;
	mwSize numPtau = numSt;
	mwSize numPrate = numSt - 1;
	mwSize numPpeq = numSt - 1;
	mwSize numPpspeq = numSp - 1;
	mwSize numPeff = 4 * numSt;	// excluding donor-only

	//pconv is a converted parameter from by appling LUbound
	gsl_vector *pconv = m_vars->pconv;//acquire real parameter
	LUbound_conv(mt_param->param, input_data, pconv);

	/* Customization starts */
//	double* n0 = new double[numPn0];
	double* n0 = new double[numSt * numSp];
	double *tau = new double[numSt];
	double *frn = new double[numSt];
	double* frnsp = new double[numSp];
//	double* effn = new double[numPeff];
	double* effn = new double[(numC - 1) * numSt * numSp];
	double* dleak = new double[numC - 1];
	double a1leak = 0;
	double* ratesumn = new double[numSt];
	double* bkgcnt = new double[numC];
	double *qplus = new double[numS];
	double *qaxis = new double[numS];
	double *qaxis2 = new double[numS];
	double frnprod = 1;
	double dq, qmax, t_th, N_th;
	double bkgcnttot = 0;

	qmax = diffparams[1];
	dq = qmax / numS;
	t_th = diffparams[2];
	N_th = diffparams[3];

	for (mwSize i = 0; i < numPn0; i++) {
		n0[i] = gsl_vector_get(pconv, i);
	}
	for (mwSize i = 0; i < numSt - 1; i++) {
		n0[i + numPn0] = n0[numPn0 - 1]; //donor-only
	}

	gsl_vector *peq = m_vars->peq;//initialize peq
	for (mwSize i = 0; i < numSt - 1; i++) {
		tau[i] = gsl_vector_get(pconv, i + numPn0);
		ratesumn[i] = gsl_vector_get(pconv, i + numPn0 + numPtau);
		frn[i] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate);
		gsl_vector_set(peq, i, frn[i] * frnprod);
		frnprod *= 1 - frn[i];
	}
	tau[numSt - 1] = gsl_vector_get(pconv, numPn0 + numPtau - 1);
	gsl_vector_set(peq, numSt - 1, frnprod);

	frnprod = 1;
	gsl_vector* pspeq = m_vars->pspeq;//initialize pspeq (species population, DA1A2, DA1, ...)
	for (mwSize i = 0; i < numSp - 1; i++) {
		frnsp[i] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq);
		gsl_vector_set(pspeq, i, frnsp[i] * frnprod);
		frnprod *= 1 - frnsp[i];
	}
	gsl_vector_set(pspeq, numSp - 1, frnprod);

	for (mwSize i = 0; i < numC - 1; i++) {
		dleak[i] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + numPpspeq + numPeff);
	} // Donor leak
	a1leak = gsl_vector_get(pconv, numPn0 + numPtau + numPrate + numPpeq + numPpspeq + numPeff + numC - 1); // A1 leak

	for (mwSize i = 0; i < (numC - 1) * numSt; i++) {
		effn[i] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + numPpspeq);
	} // DA1A2
	for (mwSize i = 0; i < numSt; i++) {
		effn[i + (numC - 1) * numSt] = (1 - a1leak) * gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + numPpspeq + (numC - 1) * numSt);
		effn[i + numSt + (numC - 1) * numSt] = a1leak * gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + numPpspeq + (numC - 1) * numSt);
	} // DA1
	for (mwSize i = 0; i < numSt; i++) {
		effn[i + numSt + (numC - 1) * 2 * numSt] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + numPpspeq + (2 * numC - 3) * numSt);
		effn[i + (numC - 1) * 2 * numSt] = (1 - effn[i + numSt + (numC - 1) * 2 * numSt]) * dleak[0] / (1 - dleak[1]);
	} // DA2
	for (mwSize i = 0; i < numC - 1; i++) {
		for (mwSize j = 0; j < numSt; j++) {
			effn[i * numSt + j + 3 * (numC - 1) * numSt] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + numPpspeq + numPeff);
		}
	} // D-only
	for (mwSize i = 0; i < numC; i++) {
		bkgcnt[i] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + numPpspeq + numPeff + numC);
		bkgcnttot += bkgcnt[i];
	}

	gsl_matrix* taumat = m_vars->taumat;
	gsl_matrix_set_zero(taumat);
	for (mwSize i = 0; i < numSt; i++) {
		gsl_matrix_set(taumat, i, i, 1/tau[i]);
	}

	gsl_matrix* ratemat0 = m_vars->ratemat0;
	gsl_matrix_set_zero(ratemat0);
	for (mwSize i = 0; i < numSt - 1; i++) {
		gsl_matrix* ratemattemp = gsl_matrix_alloc(2, 2);
		gsl_vector* peqtemp = gsl_vector_alloc(2);

		gsl_vector_set(peqtemp, 0, gsl_vector_get(peq, i));
		gsl_vector_set(peqtemp, 1, gsl_vector_get(peq, i + 1));
		gsl_vector_scale(peqtemp, 1 / (gsl_vector_get(peq, i) + gsl_vector_get(peq, i + 1)));
		ratemat0_init(ratemattemp, peqtemp, ratesumn[i]);

		gsl_matrix_set(ratemat0, i, i, gsl_matrix_get(ratemat0, i, i) + gsl_matrix_get(ratemattemp, 0, 0));
		gsl_matrix_set(ratemat0, i, i + 1, gsl_matrix_get(ratemat0, i, i + 1) + gsl_matrix_get(ratemattemp, 0, 1));
		gsl_matrix_set(ratemat0, i + 1, i, gsl_matrix_get(ratemat0, i + 1, i) + gsl_matrix_get(ratemattemp, 1, 0));
		gsl_matrix_set(ratemat0, i + 1, i + 1, gsl_matrix_get(ratemat0, i + 1, i + 1) + gsl_matrix_get(ratemattemp, 1, 1));

		gsl_matrix_free(ratemattemp);
		gsl_vector_free(peqtemp);
	}

	gsl_vector_complex *peqq = m_vars->peqq;//initialize peqq (coordinate)
	for (mwSize i = 0; i < numS; i++) {
		qplus[i] = (i + 1) * dq;
		qaxis[i] = qplus[i] - dq / 2;
		qaxis2[i] = qaxis[i] * qaxis[i];
		for (mwSize j = 0; j < numSt; j++) {
			gsl_vector_complex_set(peqq, i + j * numS, gsl_r2c(gsl_vector_get(peq, j) * qaxis2[i]));
		}
	}

	// initional and final population
	gsl_matrix_complex *pin = m_vars->pin;
	gsl_matrix_complex **pfinmat = m_vars->pfinmat;

	// Lmat0
	gsl_matrix *Lmat0 = m_vars->Lmat0;
	gsl_matrix_set_zero(Lmat0);
	for (mwSize i = 1; i < numS - 1; i++) {
		gsl_matrix_set(Lmat0, i - 1, i, qplus[i - 1] * qplus[i - 1] / qaxis[i] / qaxis[i]);
		gsl_matrix_set(Lmat0, i + 1, i, qplus[i] * qplus[i] / qaxis[i] / qaxis[i]);
		gsl_matrix_set(Lmat0, i, i, -gsl_matrix_get(Lmat0, i - 1, i) - gsl_matrix_get(Lmat0, i + 1, i));
	}
	gsl_matrix_set(Lmat0, 1, 0, qplus[0] * qplus[0] / qaxis[0] / qaxis[0]);
	gsl_matrix_set(Lmat0, 0, 0, -gsl_matrix_get(Lmat0, 1, 0));
	gsl_matrix_set(Lmat0, numS - 2, numS - 1, qplus[numS - 2] * qplus[numS - 2] / qaxis[numS - 1] / qaxis[numS - 1]);
	gsl_matrix_set(Lmat0, numS - 1, numS - 1, -gsl_matrix_get(Lmat0, numS - 2, numS - 1));
	gsl_matrix_scale(Lmat0, 1 / dq / dq);
	
	/* Customization ends */

	//Do diagonalization
	gsl_eigen_nonsymmv_workspace *W = m_vars->W;

	gsl_vector_complex *tempvec1 = gsl_vector_complex_calloc(numS2);
	gsl_vector_complex *tempvec2 = gsl_vector_complex_calloc(numS2);
	gsl_matrix_complex *tempmat = gsl_matrix_complex_calloc(numS2, numS2);

	//Diffusion matrix
	gsl_matrix_complex *eigen_valuesL = m_vars->eigen_valuesL;
	gsl_matrix_complex **eigen_Lmat = m_vars->eigen_Lmat;
	gsl_matrix_complex **inv_eigen_Lmat = m_vars->inv_eigen_Lmat;
	gsl_matrix_complex *eigen_valuesM = m_vars->eigen_valuesM;
	gsl_matrix_complex **eigen_Mmat = m_vars->eigen_Mmat;
	gsl_matrix_complex **inv_eigen_Mmat = m_vars->inv_eigen_Mmat;

	//Photon count matrix
	gsl_matrix_complex **Nmat = m_vars->Nmat;
	gsl_matrix_complex **phimat = m_vars->phimat;
	gsl_matrix_complex **NADmat = m_vars->NADmat;
	gsl_matrix_complex ***phiADmat = m_vars->phiADmat;

	gsl_vector_complex* eigen_values = gsl_vector_complex_calloc(numS2);
	gsl_vector* norm_eigen_valuesM = gsl_vector_calloc(numSp);
	gsl_matrix_complex* eigen_valuesMnorm = gsl_matrix_complex_calloc(numSp, numS2);
	double eigvalMnorm;
	gsl_matrix *NmatR = gsl_matrix_calloc(numS2, numS2);
	gsl_matrix* Kmat = gsl_matrix_calloc(numS2, numS2);
	gsl_matrix *Lmat = gsl_matrix_calloc(numS2, numS2);
	gsl_matrix* II = gsl_matrix_calloc(numS, numS);
	gsl_matrix_complex *phimattmp = gsl_matrix_complex_calloc(numS2, numS2);
	gsl_matrix *MmatR = gsl_matrix_calloc(numS2, numS2);
	gsl_matrix_complex *Mmat = gsl_matrix_complex_calloc(numS2, numS2);
	gsl_matrix* Pmat = gsl_matrix_calloc(numS, numS);

	for (mwSize ii = 0; ii < numSp; ii++) {
		for (mwSize k = 0; k < numC; k++) {
			gsl_matrix_complex_set_zero(NADmat[k]); //A1, A2, ..., Donor
		}

		gsl_matrix_set_zero(Pmat);
		for (mwSize j = 0; j < numS; j++) {
			gsl_matrix_set(Pmat, j, j, exp(-2 * qaxis2[j]));
		}

		gsl_matrix_set_zero(NmatR);
		gsl_matrix_complex_set_zero(Nmat[ii]);
		for (mwSize i = 0; i < numSt; i++) {
			for (mwSize j = 0; j < numS; j++) {
				gsl_matrix_set(NmatR, i* numS + j, i* numS + j, n0[i + numSt * ii] * gsl_matrix_get(Pmat, j, j) + bkgcnttot);
				gsl_matrix_complex_set(Nmat[ii], i * numS + j, i * numS + j, gsl_r2c(gsl_matrix_get(NmatR, i * numS + j, i * numS + j)));
				for (mwSize k = 0; k < numC - 1; k++) {
					gsl_matrix_complex_set(NADmat[k], i * numS + j, i * numS + j, gsl_r2c(effn[i + numSt * k + ii * numSt * (numC - 1)] * n0[i + numSt * ii] * gsl_matrix_get(Pmat, j, j) + bkgcnt[k]));
				}
			}
		}
		gsl_matrix_complex_memcpy(NADmat[numC - 1], Nmat[ii]);
		for (mwSize k = 0; k < numC - 1; k++) {
			gsl_matrix_complex_sub(NADmat[numC - 1], NADmat[k]);
		}

		gsl_matrix_set_identity(II);
		gsl_matrix_set_zero(Kmat);
		kron(Kmat, ratemat0, II, numSt, numS);

		kron(Lmat, taumat, Lmat0, numSt, numS);
		gsl_matrix_add(Lmat, Kmat);
		gsl_matrix_sub(Lmat, NmatR);

		gsl_eigen_nonsymmv(Lmat, eigen_values, eigen_Lmat[ii], W);
		gsl_linalg_inv(eigen_Lmat[ii], inv_eigen_Lmat[ii]);
		gsl_matrix_complex_set_row(eigen_valuesL, ii, eigen_values);

		//change to eigenspace coordinate, Nmat to phimat
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, Nmat[ii], eigen_Lmat[ii], GSL_COMPLEX_ZERO, phimattmp);
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Lmat[ii], phimattmp, GSL_COMPLEX_ZERO, phimat[ii]);

		gsl_matrix_complex_set_zero(phimattmp); //Use phimattmp as a temporary matrix to initialize Mmat
		for (mwSize j = 0; j < numS2; j++) {
			gsl_matrix_complex_set(phimattmp, j, j, gsl_r2c((exp(GSL_REAL(gsl_vector_complex_get(eigen_values, j)) * t_th) - 1) / GSL_REAL(gsl_vector_complex_get(eigen_values, j))));
		}
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, phimattmp, inv_eigen_Lmat[ii], GSL_COMPLEX_ZERO, Mmat);
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, eigen_Lmat[ii], Mmat, GSL_COMPLEX_ZERO, phimattmp);
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, Nmat[ii], phimattmp, GSL_COMPLEX_ZERO, Mmat);
		for (mwSize j = 0; j < numS2; j++)
			for (mwSize k = 0; k < numS2; k++)
				gsl_matrix_set(MmatR, j, k, GSL_REAL(gsl_matrix_complex_get(Mmat, j, k)));

		gsl_eigen_nonsymmv(MmatR, eigen_values, eigen_Mmat[ii], W);
		gsl_linalg_inv(eigen_Mmat[ii], inv_eigen_Mmat[ii]);
		gsl_matrix_complex_set_row(eigen_valuesM, ii, eigen_values);

		eigvalMnorm = gsl_vector_complex_norm(eigen_values);
		gsl_vector_set(norm_eigen_valuesM, ii, eigvalMnorm);
		gsl_vector_complex_scale(eigen_values, gsl_r2c(1 / eigvalMnorm));
		gsl_matrix_complex_set_row(eigen_valuesMnorm, ii, eigen_values);

		gsl_matrix_complex_set_zero(phimattmp); //Use phimattmp as a temporary matrix to initialize pin
		for (mwSize j = 0; j < numS2; j++) {
			gsl_matrix_complex_set(phimattmp, j, j, gsl_r2c(exp(GSL_REAL(gsl_matrix_complex_get(eigen_valuesL, ii, j)) * t_th)));
		}
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Lmat[ii], peqq, GSL_COMPLEX_ZERO, tempvec1);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, phimattmp, tempvec1, GSL_COMPLEX_ZERO, tempvec2);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_Lmat[ii], tempvec2, GSL_COMPLEX_ZERO, tempvec1);
		gsl_matrix_complex_set_row(pin, ii, tempvec1);

		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, phimattmp, inv_eigen_Lmat[ii], GSL_COMPLEX_ZERO, tempmat);
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, eigen_Lmat[ii], tempmat, GSL_COMPLEX_ZERO, pfinmat[ii]);

		for (mwSize k = 0; k < numC; k++) {
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, NADmat[k], eigen_Lmat[ii], GSL_COMPLEX_ZERO, phimattmp);
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Lmat[ii], phimattmp, GSL_COMPLEX_ZERO, phiADmat[ii][k]);
		}
	}

	// MLE cursor vector, probone
	gsl_vector_complex* probonesub = m_vars->probonesub;
	gsl_vector_complex* probonesub_t = m_vars->probonesub_t;
	gsl_vector* logL = m_vars->logL;
	gsl_vector* logZ = m_vars->logZ;
	double logLmax, logZmax;

	//compute logZ
	for (mwSize j = 0; j < numSp; j++) {
		gsl_matrix_complex_set_zero(phimattmp);
		for (mwSize i = 0; i < numS2; i++)
		{
			gsl_vector_complex_set(probonesub, i, gsl_matrix_complex_get(pin, j, i));
			gsl_matrix_complex_set(phimattmp, i, i, gsl_r2c(pow(GSL_REAL(gsl_matrix_complex_get(eigen_valuesMnorm, j, i)), N_th - 1) / (1 - GSL_REAL(gsl_matrix_complex_get(eigen_valuesMnorm, j, i)) * gsl_vector_get(norm_eigen_valuesM, j))));
		}
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Nmat[j], probonesub, GSL_COMPLEX_ZERO, probonesub_t);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Mmat[j], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, phimattmp, probonesub, GSL_COMPLEX_ZERO, probonesub_t);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_Mmat[j], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, pfinmat[j], probonesub, GSL_COMPLEX_ZERO, probonesub_t);

		gsl_vector_set(logZ, j, log(gsl_vector_complex_sum(probonesub_t)) + log(gsl_vector_get(norm_eigen_valuesM, j)) * (N_th - 1));
	}
	logZmax = gsl_vector_max(logZ);
	gsl_vector_add_constant(logZ, -logZmax);

	//data information
	double *cumindex = input_data->cumindex;
	double *indexone = input_data->indexone;
	double *frburstdata = input_data->frburstdata;
	mwSize frburst_len_n = input_data->frburst_len_n;
	mwSize frburst_len_m = input_data->frburst_len_m;
	mwSize indexone_len = input_data->indexone_len;

	//rate matrix variables
	gsl_matrix_complex *ratemat = m_vars->ratemat;
	gsl_matrix_complex *ratemat_x_E = m_vars->ratemat_x_E;
	gsl_vector_complex_view *ratemat_diag_view = &m_vars->ratemat_diag_view;

	//exponent for calculation of exponential of rate diagonal matrix
	gsl_complex exponent;

	double logamp = 0;
	double photon_interval = 1;
	double normprobone = 1;
	mwSize photon_color = 1;
	
	mt_param->probeone = 0;
	for (mwSize k = mt_param->curThread; k < indexone_len; k += maxThread)
	{
		for (mwSize j = 0; j < numSp; j++) {
			for (mwSize i = 0; i < numS2; i++)
			{
				gsl_vector_complex_set(probonesub, i, gsl_matrix_complex_get(pin, j, i));
			}
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Lmat[j], probonesub, GSL_COMPLEX_ZERO, probonesub_t);

			logamp = 0;
			photon_interval = 1;
			normprobone = 1;
			photon_color = 1;

			//for burst length
			for (mwSize ii = cumindex[mwSize(indexone[k] - 1)]; ii < cumindex[mwSize(indexone[k] - 1) + 1] - 1; ii++)
			{
				photon_interval = frburstdata[frburst_len_m * (frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m * (frburst_len_n - 3) + ii];
				photon_interval *= 1E-4; // in ms unit. 100 ns -> 1 ms
				photon_color = mwSize(frburstdata[frburst_len_m * (frburst_len_n - 1) + ii]);

				//set ratemat value
				for (mwSize i = 0; i < numS2; i++)
				{
					exponent = gsl_complex_exp(gsl_complex_mul_real(gsl_matrix_complex_get(eigen_valuesL, j, i), photon_interval));
					gsl_vector_complex_set(&ratemat_diag_view->vector, i, exponent);
				}

				gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, phiADmat[j][photon_color - 1], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
				gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

				if ((ii + 1) % 30 == 0)
				{
					normprobone = gsl_vector_complex_norm(probonesub_t);
					gsl_vector_complex_scale(probonesub_t, gsl_r2c(1 / normprobone));
					logamp += log(normprobone);
				}
			}
			//update probonesub
	//			gsl_vector_complex_memcpy(probonesub, probonesub_t);

			//the last photon
			photon_color = frburstdata[frburst_len_m * (frburst_len_n - 1) + mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)];
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, phiADmat[j][photon_color - 1], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_Lmat[j], probonesub, GSL_COMPLEX_ZERO, probonesub_t);
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, pfinmat[j], probonesub_t, GSL_COMPLEX_ZERO, probonesub);

			//logL
			gsl_vector_set(logL, j, log(gsl_vector_complex_sum(probonesub)) + logamp);
		}

		logLmax = gsl_vector_max(logL);
		gsl_vector_add_constant(logL, -logLmax);

		double Ltmp = 0;
		double Ztmp = 0;
		for (mwSize i = 0; i < numSp; i++) {
			Ltmp += exp(gsl_vector_get(logL, i)) * gsl_vector_get(pspeq, i);
			Ztmp += exp(gsl_vector_get(logZ, i)) * gsl_vector_get(pspeq, i);
		}

		mt_param->probeone += logZmax + log(Ztmp) - logLmax - log(Ltmp);
	}

	gsl_vector_complex_free(tempvec1);
	gsl_vector_complex_free(tempvec2);
	gsl_matrix_complex_free(tempmat);
	gsl_matrix_free(NmatR);
	gsl_matrix_free(Kmat);
	gsl_matrix_free(Lmat);
	gsl_matrix_free(II);
	gsl_vector_complex_free(eigen_values);
	gsl_vector_free(norm_eigen_valuesM);
	gsl_matrix_complex_free(eigen_valuesMnorm);
	gsl_matrix_complex_free(phimattmp);
	gsl_matrix_free(MmatR);
	gsl_matrix_complex_free(Mmat);
	gsl_matrix_free(Pmat);

	delete[](n0);
	delete[](tau);
	delete[](effn);
	delete[](bkgcnt);
	delete[](frn);
	delete[](frnsp);
	delete[](dleak);
	delete[](qplus);
	delete[](qaxis);
	delete[](qaxis2);

	_endthread(); // will terminate this function
	return 1; //should not be executed
}

/* Customization starts */
bool kron(gsl_matrix* Lmat00, const gsl_matrix* AA, const gsl_matrix* BB, const mwSize numSA, const mwSize numSB)
// Kronecker product
{
	for (mwSize i = 0; i < numSA; i++) {
		for (mwSize j = 0; j < numSA; j++) {
			gsl_matrix_view Lmatsub = gsl_matrix_submatrix(Lmat00, i * numSB, j * numSB, numSB, numSB);
			gsl_matrix_memcpy(&Lmatsub.matrix, BB);
			gsl_matrix_scale(&Lmatsub.matrix, gsl_matrix_get(AA, i, j));
		}
	}
	return false;
}
/* Customization ends */
