/* BurstML1 maximum likelihood method with 2-state (n=2 below) binding kinetic model for 3-color CW data (DA1A2 + DA1)
   There are three states: 3-color Bound (B3c, DA1A2), 2-color Bound (B2c, DA1), and 2-color unbound (U), B3c - U - B2c
   There are 9n-1 fitting parameters: total n*9 + numC - 4
   if numC = 3, parameters 1 to 2n-1: count rate, n0(1) ~ n0(2n-1), (n-1) DA1A2, n DA1, {total 2n-1}
				parameters 2n to 4n-2: diffusion time, tau(1) ~ tau(2n-1), (n-1) DA1A2, n DA1, {total 2n-1 parameter}
				parameters 4n-1 to 5n-3: k(1) ~ k(n-1), k(1) is the sum of foward and backward rates between state 1 and 2; {total n-1}
				parameters 5n-2 to 6n-4: f(1) ~ f(n-1), p(1) = f(1), p(2) = [1-f(1)]*f(2), p(3) = [1-f(1)]*[1-f(2)]*f(3), ...
				p(n) = [1-f(1)]*[1-f(2)]* ... *[1-f(n-1)].
				Instead of population p, a relative fraction f is used. f(i) = p(i)/(p(i)+p(i+1). Each f ranges from 0 to 1. {total n-1}
				parameters 6n-3: p3c ..., A2 labeling efficiency, same for all bound states {total 1}
				parameters 6n-2 to 8n-5: A1, A2 fraction for DA1A2, e1(1) ~ e1(n-1), e2(1) ~ e2(n-1) 
				parameters 8n-4 to 9n-5: A1+A2 fraction for DA1, E1(1) ~ E1(n),  {total 3*n-2}
				parameters 9n-4: A1 leak into A2 (= A2/[A1+A2])
				parameters 9n-3 to 9n-1: bkg cnt (A1, A2, D) {total numC} */

#include "mlhDiffNTR3cDA1CWBindbkg_MT.h"

/* Customization starts */
bool ratemat0_init(gsl_matrix* ratemat0, const gsl_vector* peq, const double ratesum)
// initialize the ratematrix using p_eq and ratesum
{
	gsl_matrix_set(ratemat0, 0, 0, -gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 0, 1, gsl_vector_get(peq, 0));
	gsl_matrix_set(ratemat0, 1, 0, gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 1, 1, -gsl_vector_get(peq, 0));
	gsl_matrix_scale(ratemat0, ratesum);
	return false;
}

/* The gateway function */
//DLL_EXPORT_SYM  // for versions 2018b and earlier
MEXFUNCTION_LINKAGE // for Matlab 2019b
void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
{
	//Set higher priority to the process
	SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);

	switch(nrhs) 
	{
		case 7: //
		{
			//MATLAB variables
			c_data *input_data=new c_data;

			if (input_from_matlab(prhs, input_data)) //assign c_data using MATLAB input prhs
			{
				mexErrMsgTxt("Error: input parameters are inconsistent!");
				return;
			}

			/* Customization starts */
			input_data->number_of_colors = mwSize(input_data->numcolor[0]);
			input_data->number_of_states = (input_data->number_of_parameters + 4 - input_data->number_of_colors) / 9;
			
			/* Customization ends*/

			gsl_vector * output_data;
			if (input_data->number_of_evaluations > 2)
			{
				output_data = calc_mlh_sub(input_data);
				output_to_matlab(output_data, plhs);
			}
			else
			{
				if (input_data->number_of_evaluations == 2) {
					input_data->number_of_evaluations = 1;
					output_data = calc_mlh_sub(input_data);
					output_to_matlab(output_data, plhs);
				}
				else {
					output_data = calc_mlh(input_data);
					output_to_matlab(output_data, plhs);
				}
			}

			//free variables
			input_data_free(input_data);
			gsl_vector_free(output_data);
		}break;

		default:
		{
			mexErrMsgTxt("Error: number of input args should be 7!");
		}
	}
	return;
}

/* Main routines */
unsigned __stdcall analysisThread(void *param)
{
	mt_vars* mt_param = (mt_vars*)param;
	c_data *input_data = mt_param->input_data;
	mlh_vars *m_vars = mt_param->m_vars;

	int cursor = mt_param->curThread;

	//mexPrintf("Thread %d invoked\n", cursor);

	mwSize numC = input_data->number_of_colors;
	mwSize numSt = input_data->number_of_states;
	mwSize numSt2 = 2 * numSt - 1;
	mwSize numP = input_data->number_of_parameters;
	mwSize numS = input_data->number_of_coords;
	mwSize numS2 = numSt2 * numS;
	double *diffparams = input_data->diffparams;

	mwSize numPn0 = numSt2;
	mwSize numPtau = numSt2;
	mwSize numPrate = numSt - 1;
	mwSize numPpeq = numSt - 1;
	mwSize numPeff = 3 * numSt - 2;
	
	//pconv is a converted parameter from by appling LUbound
	gsl_vector *pconv = m_vars->pconv;//acquire real parameter
	LUbound_conv(mt_param->param, input_data, pconv);

	/* Customization starts */
	double* n0 = new double[numPn0];
	double *tau = new double[numPtau];
	double *frn = new double[numSt];
	double p3c = 0.5;		// A2 labeling efficiency
//	double* effn = new double[numPeff];
	double* effn = new double[(numC - 1) * numSt2];
	double a1leak = 0;
	double* ratesumn = new double[numSt];
	double* bkgcnt = new double[numC];
	double *qplus = new double[numS];
	double *qaxis = new double[numS];
	double *qaxis2 = new double[numS];
	double frnprod = 1;
	double dq, qmax, t_th, N_th;
	double bkgcnttot = 0;

	qmax = diffparams[1];
	dq = qmax / numS;
	t_th = diffparams[2];
	N_th = diffparams[3];

	for (mwSize i = 0; i < numPn0; i++) {
		n0[i] = gsl_vector_get(pconv, i);
	}
	for (mwSize i = 0; i < numPtau; i++) {
		tau[i] = gsl_vector_get(pconv, i + numPn0);
	}

	p3c = gsl_vector_get(pconv, numPn0 + numPtau + numPrate + numPpeq); // A2 labeling efficiency

	gsl_vector *peq = m_vars->peq;//initialize peq
	for (mwSize i = 0; i < numSt - 1; i++) {
		ratesumn[i] = gsl_vector_get(pconv, i + numPn0 + numPtau);
		frn[i] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate);
		gsl_vector_set(peq, i, frn[i] * frnprod * p3c);		// Bound state 3-color
		gsl_vector_set(peq, i + numSt, frn[i] * frnprod * (1 - p3c));	// Bound state DA1
		frnprod *= 1 - frn[i];
	}
	gsl_vector_set(peq, numSt - 1, frnprod);	// unbound state (DA1)

	a1leak = gsl_vector_get(pconv, numPn0 + numPtau + numPrate + numPpeq + numPeff + 1); // A1 leak

	for (mwSize i = 0; i < numC - 1; i++) {
		for (mwSize j = 0; j < numSt - 1; j++) {
			effn[i * numSt2 + j] = gsl_vector_get(pconv, i * (numSt - 1) + j + numPn0 + numPtau + numPrate + numPpeq + 1);
		}
	} // DA1A2
	for (mwSize i = 0; i < numSt; i++) {
		effn[i + numSt - 1] = (1 - a1leak) * gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + 1 + (numC - 1) * (numSt - 1));
		effn[i + numSt2 + numSt - 1] = a1leak * gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + 1 + (numC - 1) * (numSt - 1));
	} // DA1

	for (mwSize i = 0; i < numC; i++) {
		bkgcnt[i] = gsl_vector_get(pconv, i + numPn0 + numPtau + numPrate + numPpeq + numPeff + 2);
		bkgcnttot += bkgcnt[i];
	}

	gsl_matrix* taumat = m_vars->taumat;
	gsl_matrix_set_zero(taumat);
	for (mwSize i = 0; i < numSt2; i++) {
		gsl_matrix_set(taumat, i, i, 1 / tau[i]);
	}

	gsl_matrix* ratemat0 = m_vars->ratemat0;	// kind of hub model, B1, ..., Bn are connected to U. no transitions between the bound states.
	gsl_matrix_set_zero(ratemat0);
	for (mwSize i = 0; i < numSt - 1; i++) {
		gsl_matrix* ratemattemp = gsl_matrix_alloc(2, 2);
		gsl_vector* peqtemp = gsl_vector_alloc(2);

		gsl_vector_set(peqtemp, 0, gsl_vector_get(peq, i) + gsl_vector_get(peq, i + numSt));
		gsl_vector_set(peqtemp, 1, gsl_vector_get(peq, numSt - 1)); // unbound state
		gsl_vector_scale(peqtemp, 1 / (gsl_vector_get(peqtemp, 0) + gsl_vector_get(peqtemp, 1)));
		ratemat0_init(ratemattemp, peqtemp, ratesumn[i]);

		gsl_matrix_set(ratemat0, i, i, gsl_matrix_get(ratemat0, i, i) + gsl_matrix_get(ratemattemp, 0, 0));
		gsl_matrix_set(ratemat0, i, numSt - 1, gsl_matrix_get(ratemat0, i, numSt - 1) + p3c * gsl_matrix_get(ratemattemp, 0, 1));
		gsl_matrix_set(ratemat0, numSt - 1, i, gsl_matrix_get(ratemat0, numSt - 1, i) + gsl_matrix_get(ratemattemp, 1, 0));
		gsl_matrix_set(ratemat0, numSt - 1, numSt - 1, gsl_matrix_get(ratemat0, numSt - 1, numSt - 1) + gsl_matrix_get(ratemattemp, 1, 1));

		gsl_matrix_set(ratemat0, i + numSt, i + numSt, gsl_matrix_get(ratemat0, i + numSt, i + numSt) + gsl_matrix_get(ratemattemp, 0, 0));
		gsl_matrix_set(ratemat0, i + numSt, numSt - 1, gsl_matrix_get(ratemat0, i + numSt, numSt - 1) + (1 - p3c) * gsl_matrix_get(ratemattemp, 0, 1));
		gsl_matrix_set(ratemat0, numSt - 1, i + numSt, gsl_matrix_get(ratemat0, numSt - 1, i + numSt) + gsl_matrix_get(ratemattemp, 1, 0));

		gsl_matrix_free(ratemattemp);
		gsl_vector_free(peqtemp);
	}

	gsl_vector_complex *peqq = m_vars->peqq;//initialize peqq (coordinate)
	for (mwSize i = 0; i < numS; i++) {
		qplus[i] = (i + 1) * dq;
		qaxis[i] = qplus[i] - dq / 2;
		qaxis2[i] = qaxis[i] * qaxis[i];
		for (mwSize j = 0; j < numSt2; j++) {
			gsl_vector_complex_set(peqq, i + j * numS, gsl_r2c(gsl_vector_get(peq, j) * qaxis2[i]));
		}
	}

	// initional and final population
	gsl_vector_complex *pin = m_vars->pin;
	gsl_matrix_complex *pfinmat = m_vars->pfinmat;

	// Lmat0
	gsl_matrix *Lmat0 = m_vars->Lmat0;
	gsl_matrix_set_zero(Lmat0);
	for (mwSize i = 1; i < numS - 1; i++) {
		gsl_matrix_set(Lmat0, i - 1, i, qplus[i - 1] * qplus[i - 1] / qaxis[i] / qaxis[i]);
		gsl_matrix_set(Lmat0, i + 1, i, qplus[i] * qplus[i] / qaxis[i] / qaxis[i]);
		gsl_matrix_set(Lmat0, i, i, -gsl_matrix_get(Lmat0, i - 1, i) - gsl_matrix_get(Lmat0, i + 1, i));
	}
	gsl_matrix_set(Lmat0, 1, 0, qplus[0] * qplus[0] / qaxis[0] / qaxis[0]);
	gsl_matrix_set(Lmat0, 0, 0, -gsl_matrix_get(Lmat0, 1, 0));
	gsl_matrix_set(Lmat0, numS - 2, numS - 1, qplus[numS - 2] * qplus[numS - 2] / qaxis[numS - 1] / qaxis[numS - 1]);
	gsl_matrix_set(Lmat0, numS - 1, numS - 1, -gsl_matrix_get(Lmat0, numS - 2, numS - 1));
	gsl_matrix_scale(Lmat0, 1 / dq / dq);
	
	/* Customization ends */

	//Do diagonalization
	gsl_eigen_nonsymmv_workspace *W = m_vars->W;

	gsl_vector_complex *tempvec1 = gsl_vector_complex_calloc(numS2);
	gsl_vector_complex *tempvec2 = gsl_vector_complex_calloc(numS2);
	gsl_matrix_complex *tempmat = gsl_matrix_complex_calloc(numS2, numS2);

	//Diffusion matrix
	gsl_vector_complex *eigen_valuesL = m_vars->eigen_valuesL;
	gsl_matrix_complex *eigen_Lmat = m_vars->eigen_Lmat;
	gsl_matrix_complex *inv_eigen_Lmat = m_vars->inv_eigen_Lmat;
	gsl_vector_complex *eigen_valuesM = m_vars->eigen_valuesM;
	gsl_matrix_complex *eigen_Mmat = m_vars->eigen_Mmat;
	gsl_matrix_complex *inv_eigen_Mmat = m_vars->inv_eigen_Mmat;

	//Photon count matrix
	gsl_matrix_complex *Nmat = m_vars->Nmat;
	gsl_matrix_complex *phimat = m_vars->phimat;
	gsl_matrix_complex **NADmat = m_vars->NADmat;
	gsl_matrix_complex **phiADmat = m_vars->phiADmat;

	gsl_matrix *NmatR = gsl_matrix_calloc(numS2, numS2);
	gsl_matrix* Kmat = gsl_matrix_calloc(numS2, numS2);
	gsl_matrix *Lmat = gsl_matrix_calloc(numS2, numS2);
	gsl_matrix* II = gsl_matrix_calloc(numS, numS);
	gsl_matrix_complex *phimattmp = gsl_matrix_complex_calloc(numS2, numS2);
	gsl_matrix *MmatR = gsl_matrix_calloc(numS2, numS2);
	gsl_matrix_complex *Mmat = gsl_matrix_complex_calloc(numS2, numS2);
	gsl_matrix* Pmat = gsl_matrix_calloc(numS, numS);

	for (mwSize k = 0; k < numC; k++) {
		gsl_matrix_complex_set_zero(NADmat[k]); //A1, A2, ..., Donor
	}

	gsl_matrix_set_zero(Pmat);
	for (mwSize j = 0; j < numS; j++) {
		gsl_matrix_set(Pmat, j, j, exp(-2 * qaxis2[j]));
	}

	gsl_matrix_set_zero(NmatR);
	gsl_matrix_complex_set_zero(Nmat);
	for (mwSize i = 0; i < numSt2; i++) {
		for (mwSize j = 0; j < numS; j++) {
			gsl_matrix_set(NmatR, i * numS + j, i * numS + j, n0[i] * gsl_matrix_get(Pmat, j, j) + bkgcnttot);
			gsl_matrix_complex_set(Nmat, i * numS + j, i * numS + j, gsl_r2c(gsl_matrix_get(NmatR, i * numS + j, i * numS + j)));
			for (mwSize k = 0; k < numC - 1; k++) {
				gsl_matrix_complex_set(NADmat[k], i * numS + j, i * numS + j, gsl_r2c(effn[i + numSt2 * k] * n0[i] * gsl_matrix_get(Pmat, j, j) + bkgcnt[k]));
			}
		}
	}
	gsl_matrix_complex_memcpy(NADmat[numC - 1], Nmat);
	for (mwSize k = 0; k < numC - 1; k++) {
		gsl_matrix_complex_sub(NADmat[numC - 1], NADmat[k]);
	}

	gsl_matrix_set_identity(II);
	gsl_matrix_set_zero(Kmat);
	kron(Kmat, ratemat0, II, numSt2, numS);

	kron(Lmat, taumat, Lmat0, numSt2, numS);
	gsl_matrix_add(Lmat, Kmat);
	gsl_matrix_sub(Lmat, NmatR);

	gsl_eigen_nonsymmv(Lmat, eigen_valuesL, eigen_Lmat, W);
	gsl_linalg_inv(eigen_Lmat, inv_eigen_Lmat);

	//change to eigenspace coordinate, Nmat to phimat
	gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, Nmat, eigen_Lmat, GSL_COMPLEX_ZERO, phimattmp);
	gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Lmat, phimattmp, GSL_COMPLEX_ZERO, phimat);

	gsl_matrix_complex_set_zero(phimattmp); //Use phimattmp as a temporary matrix to initialize Mmat
	for (mwSize j = 0; j < numS2; j++) {
		gsl_matrix_complex_set(phimattmp, j, j, gsl_r2c((exp(GSL_REAL(gsl_vector_complex_get(eigen_valuesL, j)) * t_th) - 1) / GSL_REAL(gsl_vector_complex_get(eigen_valuesL, j))));
	}
	gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, phimattmp, inv_eigen_Lmat, GSL_COMPLEX_ZERO, Mmat);
	gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, eigen_Lmat, Mmat, GSL_COMPLEX_ZERO, phimattmp);
	gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, Nmat, phimattmp, GSL_COMPLEX_ZERO, Mmat);
	for (mwSize j = 0; j < numS2; j++)
		for (mwSize k = 0; k < numS2; k++)
			gsl_matrix_set(MmatR, j, k, GSL_REAL(gsl_matrix_complex_get(Mmat, j, k)));

	gsl_eigen_nonsymmv(MmatR, eigen_valuesM, eigen_Mmat, W);
	gsl_linalg_inv(eigen_Mmat, inv_eigen_Mmat);

	gsl_matrix_complex_set_zero(phimattmp); //Use phimattmp as a temporary matrix to initialize pin
	for (mwSize j = 0; j < numS2; j++) {
		gsl_matrix_complex_set(phimattmp, j, j, gsl_r2c(exp(GSL_REAL(gsl_vector_complex_get(eigen_valuesL, j)) * t_th)));
	}
	gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Lmat, peqq, GSL_COMPLEX_ZERO, tempvec1);
	gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, phimattmp, tempvec1, GSL_COMPLEX_ZERO, tempvec2);
	gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_Lmat, tempvec2, GSL_COMPLEX_ZERO, pin);

	gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, phimattmp, inv_eigen_Lmat, GSL_COMPLEX_ZERO, tempmat);
	gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, eigen_Lmat, tempmat, GSL_COMPLEX_ZERO, pfinmat);

	for (mwSize k = 0; k < numC; k++) {
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, NADmat[k], eigen_Lmat, GSL_COMPLEX_ZERO, phimattmp);
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Lmat, phimattmp, GSL_COMPLEX_ZERO, phiADmat[k]);
	}
	

	// MLE cursor vector, probone
	gsl_vector_complex* probonesub = m_vars->probonesub;
	gsl_vector_complex* probonesub_t = m_vars->probonesub_t;
	double logL, logZ;

	//compute logZ
	gsl_matrix_complex_set_zero(phimattmp);
	for (mwSize i = 0; i < numS2; i++)
	{
		gsl_vector_complex_set(probonesub, i, gsl_vector_complex_get(pin, i));
		gsl_matrix_complex_set(phimattmp, i, i, gsl_r2c(pow(GSL_REAL(gsl_vector_complex_get(eigen_valuesM, i)), N_th - 1) / (1 - GSL_REAL(gsl_vector_complex_get(eigen_valuesM, i)))));
	}
	gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Nmat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);
	gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Mmat, probonesub_t, GSL_COMPLEX_ZERO, probonesub);
	gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, phimattmp, probonesub, GSL_COMPLEX_ZERO, probonesub_t);
	gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_Mmat, probonesub_t, GSL_COMPLEX_ZERO, probonesub);
	gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, pfinmat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

	logZ = log(gsl_vector_complex_sum(probonesub_t));

	//data information
	double *cumindex = input_data->cumindex;
	double *indexone = input_data->indexone;
	double *frburstdata = input_data->frburstdata;
	mwSize frburst_len_n = input_data->frburst_len_n;
	mwSize frburst_len_m = input_data->frburst_len_m;
	mwSize indexone_len = input_data->indexone_len;

	//rate matrix variables
	gsl_matrix_complex *ratemat = m_vars->ratemat;
	gsl_matrix_complex *ratemat_x_E = m_vars->ratemat_x_E;
	gsl_vector_complex_view *ratemat_diag_view = &m_vars->ratemat_diag_view;

	//exponent for calculation of exponential of rate diagonal matrix
	gsl_complex exponent;

	double logamp = 0;
	double photon_interval = 1;
	double normprobone = 1;
	mwSize photon_color = 1;
	
	mt_param->probeone = 0;
	for (mwSize k = mt_param->curThread; k < indexone_len; k += maxThread)
	{
		for (mwSize i = 0; i < numS2; i++)
		{
			gsl_vector_complex_set(probonesub, i, gsl_vector_complex_get(pin, i));
		}
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_Lmat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

		logamp = 0;
		photon_interval = 1;
		normprobone = 1;
		photon_color = 1;

		//for burst length
		for (mwSize ii = cumindex[mwSize(indexone[k] - 1)]; ii < cumindex[mwSize(indexone[k] - 1) + 1] - 1; ii++)
		{
			photon_interval = frburstdata[frburst_len_m * (frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m * (frburst_len_n - 3) + ii];
			photon_interval *= 1E-4; // in ms unit. 100 ns -> 1 ms
			photon_color = mwSize(frburstdata[frburst_len_m * (frburst_len_n - 1) + ii]);

			//set ratemat value
			for (mwSize i = 0; i < numS2; i++)
			{
				exponent = gsl_complex_exp(gsl_complex_mul_real(gsl_vector_complex_get(eigen_valuesL, i), photon_interval));
				gsl_vector_complex_set(&ratemat_diag_view->vector, i, exponent);
			}

			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, phiADmat[photon_color - 1], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

			if ((ii + 1) % 30 == 0)
			{
				normprobone = gsl_vector_complex_norm(probonesub_t);
				gsl_vector_complex_scale(probonesub_t, gsl_r2c(1 / normprobone));
				logamp += log(normprobone);
			}
		}
		//update probonesub
//			gsl_vector_complex_memcpy(probonesub, probonesub_t);

		//the last photon
		photon_color = frburstdata[frburst_len_m * (frburst_len_n - 1) + mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)];
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, phiADmat[photon_color - 1], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_Lmat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, pfinmat, probonesub_t, GSL_COMPLEX_ZERO, probonesub);

		//logL
		logL = log(gsl_vector_complex_sum(probonesub)) + logamp;

		mt_param->probeone += logZ - logL;
	}

	gsl_vector_complex_free(tempvec1);
	gsl_vector_complex_free(tempvec2);
	gsl_matrix_complex_free(tempmat);
	gsl_matrix_free(NmatR);
	gsl_matrix_free(Kmat);
	gsl_matrix_free(Lmat);
	gsl_matrix_free(II);
	gsl_matrix_complex_free(phimattmp);
	gsl_matrix_free(MmatR);
	gsl_matrix_complex_free(Mmat);
	gsl_matrix_free(Pmat);

	delete[](n0);
	delete[](tau);
	delete[](effn);
	delete[](bkgcnt);
	delete[](frn);
	delete[](qplus);
	delete[](qaxis);
	delete[](qaxis2);

	_endthread(); // will terminate this function
	return 1; //should not be executed
}

/* Customization starts */
bool kron(gsl_matrix* Lmat00, const gsl_matrix* AA, const gsl_matrix* BB, const mwSize numSA, const mwSize numSB)
// Kronecker product
{
	for (mwSize i = 0; i < numSA; i++) {
		for (mwSize j = 0; j < numSA; j++) {
			gsl_matrix_view Lmatsub = gsl_matrix_submatrix(Lmat00, i * numSB, j * numSB, numSB, numSB);
			gsl_matrix_memcpy(&Lmatsub.matrix, BB);
			gsl_matrix_scale(&Lmatsub.matrix, gsl_matrix_get(AA, i, j));
		}
	}
	return false;
}
/* Customization ends */
