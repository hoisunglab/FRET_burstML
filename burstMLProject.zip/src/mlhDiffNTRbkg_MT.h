#include <Windows.h>
#include <process.h>
#include <stdlib.h>

// The following lines must be located BEFORE '#include <mex.h>'
#ifdef _MSC_VER
#define DLL_EXPORT_SYM __declspec(dllexport)
#else
#define DLL_EXPORT_SYM
#endif

#define MW_NEEDS_VERSION_H // Needed for Matlab 2019b

#include <mex.h>
#include <matrix.h>
#include <math.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_eigen.h.>
#include <gsl/gsl_complex.h>
#include <gsl/gsl_complex_math.h>
#include <gsl/gsl_linalg.h>

/* global variables for multithreading */
const size_t maxThread = 24;
volatile HANDLE Threads[maxThread];
unsigned int threadIDs[maxThread];

// C data structure of input variables 
typedef struct _C_DATA {
	double *initparams, *LUbounds, *frburstdata, *cumindex, *indexone, *E, *params, *cntrate, *diffparams, *numcolor;
	
	mwSize number_of_parameters;
	mwSize number_of_states;
	mwSize number_of_colors;
	mwSize cumindex_len;
	mwSize indexone_len;
	mwSize frburst_len_m;
	mwSize frburst_len_n;
	mwSize number_of_coords;

	mwSize number_of_evaluations;

	gsl_vector *L_bound;
	gsl_vector *U_bound;
} c_data;


/* variables for mlhratesub. It would be better to make a class... */
typedef struct _MLH_VARS {
gsl_vector *pconv;
gsl_vector *peq;
gsl_vector_complex *peqq;
gsl_vector_complex *pin;
gsl_matrix_complex *pfinmat;

//Diffusion matrices
gsl_matrix *Lmat0;
gsl_eigen_nonsymmv_workspace *W;
gsl_vector_complex* eigen_valuesL;
gsl_matrix_complex *eigen_Lmat;
gsl_matrix_complex *inv_eigen_Lmat;
gsl_vector_complex* eigen_valuesM;
gsl_matrix_complex *eigen_Mmat;
gsl_matrix_complex *inv_eigen_Mmat;

//Kinetics matrix
gsl_matrix* ratemat0;
gsl_matrix* taumat;

//Photon count matrix
gsl_matrix_complex *Nmat;
gsl_matrix_complex *phimat;
gsl_matrix_complex **NADmat;
gsl_matrix_complex **phiADmat;

// MLE cursor vector, probone
gsl_vector_complex *probonesub;
gsl_vector_complex *probonesub_t;
//rate matrix variables
gsl_matrix_complex *ratemat;
gsl_matrix_complex *ratemat_x_E;
gsl_vector_complex_view ratemat_diag_view;

} mlh_vars;

typedef struct _MLH_MT_VARS {
	gsl_vector * param;
	mlh_vars * m_vars;
	unsigned curThread;
	c_data *input_data;
	double probeone;
} mt_vars;

typedef struct _MLH_PARAM_PACK {
c_data *data;
mlh_vars *vars;
} mlh_param_pack;

/* Main routines */
bool input_from_matlab( const mxArray *prhs[] ,c_data *input_data); // Initialize input data using MATLAB input
bool init_mlh_vars(mlh_vars *var, const c_data *input_data);
double mlhratesub (const gsl_vector * param, void * c_data); 		// Return MLE for the given parammeter and c_data. The function to be minimized.
gsl_vector *calc_mlh(c_data *input_data); 							// Find maximum-likelihood parameter
gsl_vector *calc_mlh_sub(c_data *input_data);	// for error calc.
bool output_to_matlab(gsl_vector *output_data, mxArray *prls[]);		// Relay the parameter to MATLAB

/* mlhratesub sub-routines */
bool init_mlh_vars(mlh_vars *var, const c_data *input_data);	//dynamics allocation of mlh_vars
bool free_mlh_vars(mlh_vars *var, const c_data *input_data);

int LUbound_conv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv); 		//convert unbound param to bound pconv
int LUbound_invconv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv); 	//convert bound param to unbound pconv

/* GSL utililties */
int gsl_linalg_inv (const gsl_matrix_complex * A,gsl_matrix_complex *  inv_A); //calculate inverse matrix of A using LU decomposition
gsl_complex gsl_r2c(double r);	//convert real variable r to complex variable r+0i
double gsl_vector_complex_norm(gsl_vector_complex *v);	//calculate norm of vector v
double gsl_vector_complex_sum(gsl_vector_complex *v);	//summate absolute value of each element of v

/* Destructor */
bool input_data_free(c_data * input_data);	// free input_data

// CPU MT
unsigned __stdcall analysisThread(void *param);


bool input_from_matlab(const mxArray *prhs[], c_data *input_data)
// Initialize input data using MATLAB input
{
	input_data->initparams = mxGetPr(prhs[0]);
	input_data->LUbounds = mxGetPr(prhs[1]);
	input_data->frburstdata = mxGetPr(prhs[2]);
	input_data->cumindex = mxGetPr(prhs[3]);
	input_data->indexone = mxGetPr(prhs[4]);
	input_data->diffparams = mxGetPr(prhs[5]);
	input_data->numcolor = mxGetPr(prhs[6]);

	input_data->number_of_parameters = mxGetM(prhs[0]);
	
	input_data->number_of_evaluations = mxGetN(prhs[0]);

	input_data->number_of_coords = mwSize(input_data->diffparams[0]);

	input_data->cumindex_len = mxGetNumberOfElements(prhs[3]);
	input_data->indexone_len = mxGetNumberOfElements(prhs[4]);
	input_data->frburst_len_m = mxGetM(prhs[2]);
	input_data->frburst_len_n = mxGetN(prhs[2]);

	input_data->L_bound = gsl_vector_calloc(input_data->number_of_parameters);
	input_data->U_bound = gsl_vector_calloc(input_data->number_of_parameters);

	for (mwSize i = 0; i<input_data->number_of_parameters; i++)
	{
		gsl_vector_set(input_data->L_bound, i, input_data->LUbounds[i]);
		gsl_vector_set(input_data->U_bound, i, input_data->LUbounds[input_data->number_of_parameters + i]);
	}

	/* Consistency check */
	// number_of_parameters should be consistent
	if (mxGetM(prhs[1]) != input_data->number_of_parameters)
	{
		mexPrintf("numel(LUbound)=%d, numOfParam=%d\n", mxGetM(prhs[1]), input_data->number_of_parameters);
		return true;
	}
	// A parameter should be between its LU bound
	for (size_t i = 0; i < input_data->number_of_parameters; i++)
	{
		if (input_data->initparams[i] < input_data->LUbounds[i]) return true;
		if (input_data->LUbounds[input_data->number_of_parameters + i] < input_data->initparams[i]) return true;
	}
	return false;
}

double mlhratesub(const gsl_vector * param, void * input_pack)
// Return MLE for the given parammeter and c_data. The function to be minimized.
{
	mt_vars *mt_param = (mt_vars *)input_pack;
	c_data *input_data = mt_param[0].input_data;

	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_memcpy(mt_param[i].param, param);
		mt_param[i].curThread = i;
		Threads[i] = (HANDLE)_beginthreadex(NULL, 0, &analysisThread, (void *)&mt_param[i], 0, &threadIDs[i]);
	}

	for (int i = 0; i < maxThread; i++)
	{
		WaitForSingleObject(Threads[i], INFINITE);
	}

	for (int i = 1; i < maxThread; i++) mt_param[0].probeone += mt_param[i].probeone; //sum up probeone of each thread
	return mt_param[0].probeone;
}

gsl_vector *calc_mlh(c_data *input_data)
// Find maximum-likelihood parameter
{
	const gsl_multimin_fminimizer_type *T =
		gsl_multimin_fminimizer_nmsimplex2;//gsl_multimin_fminimizer_nmsimplex2rand
	gsl_multimin_fminimizer *s = NULL;
	gsl_vector *ss, *x, *init_param, *output_param;
	gsl_multimin_function minex_func;

	size_t iter = 0;
	int status;
	double size;

	mlh_vars *m_vars = new mlh_vars;
	mlh_param_pack *m_pack = new mlh_param_pack;
	m_pack->data = input_data;
	m_pack->vars = m_vars;

	init_mlh_vars(m_vars, input_data);

	mt_vars mt_param[maxThread];
	for (int i = 0; i < maxThread; i++)
	{
		mt_param[i].param = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].m_vars = new mlh_vars;
		mt_param[i].input_data = input_data;
		init_mlh_vars(mt_param[i].m_vars, input_data);
	}

	init_param = gsl_vector_calloc(input_data->number_of_parameters);
	output_param = gsl_vector_calloc(input_data->number_of_parameters);

	/* Starting point */
	x = gsl_vector_calloc(input_data->number_of_parameters);

	for (size_t i = 0; i<input_data->number_of_parameters; i++)
	{
		gsl_vector_set(init_param, i, input_data->initparams[i]);
	}
	LUbound_invconv(init_param, input_data, x);

	/* Set initial step sizes to 1 */
	ss = gsl_vector_calloc(input_data->number_of_parameters);
	gsl_vector_set_all(ss, 1.0);

	/* Initialize method and iterate */
	minex_func.n = input_data->number_of_parameters;
	minex_func.f = &mlhratesub;

	minex_func.params = mt_param;
	s = gsl_multimin_fminimizer_alloc(T, input_data->number_of_parameters);
	gsl_multimin_fminimizer_set(s, &minex_func, x, ss);

	do
	{
		iter++;
		status = gsl_multimin_fminimizer_iterate(s);

		if (status)
			break;

		size = gsl_multimin_fminimizer_size(s);
		status = gsl_multimin_test_size(size, 1e-3);
		//status = gsl_multimin_test_size (size, 1e-4);

		/*
		if (status == GSL_SUCCESS)
		{
		mexPrintf ("converged to minimum at\n");
		}
		mexPrintf ("%5d %10.3e %10.3e %10.3e %10.3e f() = %7.3f size = %.3f\n",
		iter,
		gsl_vector_get (s->x, 0),
		gsl_vector_get (s->x, 1),
		gsl_vector_get (s->x, 2),
		gsl_vector_get (s->x, 3),
		s->fval, size);
		*/

	} while (status == GSL_CONTINUE && iter < 2000);

	if (iter == 2000)
	{
		mexPrintf("Warning: 2000 interations, the minimizer terminated before converge\n");
	}
	/*	  mexPrintf ("%5d %10.3e %10.3e %10.3e %10.3e f() = %7.3f size = %.3f\n",
	iter,
	gsl_vector_get (s->x, 0),
	gsl_vector_get (s->x, 1),
	gsl_vector_get (s->x, 2),
	gsl_vector_get (s->x, 3),
	s->fval, size);
	*/
	LUbound_conv(s->x, input_data, output_param);

	gsl_vector_free(x);
	gsl_vector_free(ss);
	gsl_multimin_fminimizer_free(s);

	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_free(mt_param[i].param);
		free_mlh_vars(mt_param[i].m_vars, input_data);
		free(mt_param[i].m_vars);
	}

	free_mlh_vars(m_vars, input_data);
	gsl_vector_free(init_param);
	delete(m_vars);
	delete(m_pack);

	//gsl_vector output_param will be freed in the main function
	return output_param;
}

gsl_vector *calc_mlh_sub(c_data *input_data)
// Return logmlh values
{
	gsl_vector *x, *init_param, *output_param;
	init_param = gsl_vector_calloc(input_data->number_of_parameters);
	x = gsl_vector_calloc(input_data->number_of_parameters);
	output_param = gsl_vector_calloc(input_data->number_of_evaluations);
	mlh_vars *m_vars = new mlh_vars;
	mlh_param_pack *m_pack = new mlh_param_pack;
	m_pack->data = input_data;
	m_pack->vars = m_vars;
	init_mlh_vars(m_vars, input_data);
	mt_vars mt_param[maxThread];
	for (int i = 0; i < maxThread; i++)
	{
		mt_param[i].param = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].m_vars = new mlh_vars;
		mt_param[i].input_data = input_data;
		init_mlh_vars(mt_param[i].m_vars, input_data);
	}

	void * input_pack = mt_param;
	for (size_t i = 0; i<input_data->number_of_evaluations; i++)
	{
		for (size_t j = 0; j<input_data->number_of_parameters; j++) // interation on initparams
		{
			gsl_vector_set(init_param, j, input_data->initparams[i*input_data->number_of_parameters + j]);
		}
		LUbound_invconv(init_param, input_data, x);
		gsl_vector_set(output_param, i, mlhratesub(x, input_pack)); //save mlhratesub value to output_param
	}
	free_mlh_vars(m_vars, input_data);

	for (int i = 0; i < maxThread; i++)
	{
		free_mlh_vars(mt_param[i].m_vars, input_data);
		free(mt_param[i].m_vars);
		gsl_vector_free(mt_param[i].param);
	}
	delete(m_vars);
	delete(m_pack);

	gsl_vector_free(init_param);
	gsl_vector_free(x);

	//gsl_vector output_param will be freed in the main function
	return output_param;
}

bool output_to_matlab(gsl_vector *output_data, mxArray *plhs[])
// Relay the output parameter to MATLAB
{
	plhs[0] = mxCreateDoubleMatrix(output_data->size, 1, mxREAL);
	double * output = mxGetPr(plhs[0]);
	for (mwSize i = 0; i<output_data->size; i++)
	{
		output[i] = gsl_vector_get(output_data, i);
	}

	return true;
}


/* mlhratesub sub-routines */
bool init_mlh_vars(mlh_vars *var, const c_data *input_data)
//pre-allocate dynamic variables that repeatedly used in calc_mlh
{
	const mwSize numC = input_data->number_of_colors;
	const mwSize numSt = input_data->number_of_states;
	const mwSize numP = input_data->number_of_parameters;
	const mwSize numS = input_data->number_of_coords;
	const mwSize numS2 = numSt * numS;

	//pconv is a converted parameter from by appling LUbound
	var->pconv = gsl_vector_calloc(numP);

	var->peq = gsl_vector_calloc(numSt);
	var->peqq = gsl_vector_complex_calloc(numS2);
	var->pin = gsl_vector_complex_calloc(numS2);
	var->pfinmat = gsl_matrix_complex_calloc(numS2, numS2);

	var->ratemat0 = gsl_matrix_calloc(numSt, numSt);
	var->taumat = gsl_matrix_calloc(numSt, numSt);

	//Diffusion matrices
	var->Lmat0 = gsl_matrix_calloc(numS, numS);
	var->W = gsl_eigen_nonsymmv_alloc(numS2);
	
	var->eigen_valuesL = gsl_vector_complex_calloc(numS2);
	var->eigen_Lmat = gsl_matrix_complex_calloc(numS2, numS2);
	var->inv_eigen_Lmat = gsl_matrix_complex_calloc(numS2, numS2);
	var->eigen_valuesM = gsl_vector_complex_calloc(numS2);
	var->eigen_Mmat = gsl_matrix_complex_calloc(numS2, numS2);
	var->inv_eigen_Mmat = gsl_matrix_complex_calloc(numS2, numS2);

	//Photon count matrix
	var->Nmat = gsl_matrix_complex_calloc(numS2, numS2);
	var->phimat = gsl_matrix_complex_calloc(numS2, numS2);
	var->NADmat = new gsl_matrix_complex*[numC];
	var->phiADmat = new gsl_matrix_complex*[numC];
	for (mwSize i = 0; i < numC; i++)
	{
		var->NADmat[i] = gsl_matrix_complex_calloc(numS2, numS2);
		var->phiADmat[i] = gsl_matrix_complex_calloc(numS2, numS2);
	}

	// MLE cursor vector, probone
	var->probonesub = gsl_vector_complex_calloc(numS2);
	var->probonesub_t = gsl_vector_complex_calloc(numS2);

	//rate matrix variables
	var->ratemat = gsl_matrix_complex_calloc(numS2, numS2);
	var->ratemat_x_E = gsl_matrix_complex_calloc(numS2, numS2);
	var->ratemat_diag_view = gsl_matrix_complex_diagonal(var->ratemat);
	return false;
}

bool free_mlh_vars(mlh_vars *var, const c_data *input_data)
{
	const mwSize numS = input_data->number_of_coords;
	const mwSize numSt = input_data->number_of_states;
	const mwSize numP = input_data->number_of_parameters;
	const mwSize numC = input_data->number_of_colors;

	//pconv is a converted parameter from by appling LUbound
	gsl_vector_free(var->pconv);
	gsl_vector_free(var->peq);
	gsl_vector_complex_free(var->pin);
	gsl_vector_complex_free(var->peqq);

	gsl_matrix_free(var->ratemat0);
	gsl_matrix_free(var->taumat);
	gsl_matrix_free(var->Lmat0);
	gsl_eigen_nonsymmv_free(var->W);
	gsl_vector_complex_free(var->eigen_valuesL);
	gsl_vector_complex_free(var->eigen_valuesM);

	//Photon count matrix
	for (mwSize i = 0; i<numC; i++)
	{
		gsl_matrix_complex_free(var->NADmat[i]);
		gsl_matrix_complex_free(var->phiADmat[i]);
	}

	delete(var->pfinmat);
	delete(var->eigen_Lmat);
	delete(var->inv_eigen_Lmat);
	delete(var->eigen_Mmat);
	delete(var->inv_eigen_Mmat);
	delete(var->Nmat);
	delete(var->phimat);
	delete(var->NADmat);
	delete(var->phiADmat);

	// MLE cursor vector, probone
	gsl_vector_complex_free(var->probonesub);
	gsl_vector_complex_free(var->probonesub_t);

	//rate matrix variables
	gsl_matrix_complex_free(var->ratemat);
	gsl_matrix_complex_free(var->ratemat_x_E);
	return false;
}

/* Customization starts */
bool kron(gsl_matrix* Lmat00, const gsl_matrix* AA, const gsl_matrix* BB, const mwSize numSA, const mwSize numSB);
// Kronecker product
/* Customization ends */


int LUbound_conv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv)
//convert unbound param to bound pconv
{
	gsl_vector *temp = gsl_vector_calloc(param->size);

	gsl_vector_memcpy(temp, param);
	gsl_vector_mul(temp, param); //temp=param^2
	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound); //pconv=U-L
	gsl_vector_add_constant(temp, 1.0);//temp=1+param^2;
	gsl_vector_div(pconv, temp);//pconv=(U-L)/(1+param^2);
	gsl_vector_add(pconv, input_data->L_bound);//pconv=(U-L)/(1+param^2)+L;

	gsl_vector_free(temp);
	return 0;
}

int LUbound_invconv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv)
//convert bound param to unbound pconv
{
	gsl_vector *temp = gsl_vector_calloc(param->size);
	gsl_vector_memcpy(temp, param);
	gsl_vector_sub(temp, input_data->L_bound);//temp=param-L

	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound);//pconv=U-L
	gsl_vector_div(pconv, temp);//pconv=(U-L)/(param-L);
	gsl_vector_add_constant(pconv, -1);//pconv=(U-L)/(param-L)-1
	for (int i = 0; i<param->size; i++)
	{
		gsl_vector_set(pconv, i, sqrt(gsl_vector_get(pconv, i)));
	}
	gsl_vector_free(temp);
	return 0;
}

/* GSL utililties */
int gsl_linalg_inv(const gsl_matrix_complex * A, gsl_matrix_complex *  inv_A)
//calculate inverse matrix of A using LU decomposition
{
	gsl_matrix_complex *A_copy = gsl_matrix_complex_calloc(A->size1, A->size2);
	gsl_matrix_complex_memcpy(A_copy, A);
	gsl_permutation *p = gsl_permutation_calloc(A->size1);
	int signum = 0;
	gsl_linalg_complex_LU_decomp(A_copy, p, &signum);
	gsl_linalg_complex_LU_invert(A_copy, p, inv_A);

	gsl_matrix_complex_free(A_copy);
	gsl_permutation_free(p);
	return 0;
}

gsl_complex gsl_r2c(double r)
//convert real variable r to complex variable r+0i
{
	gsl_complex c;
	GSL_SET_COMPLEX(&c, r, 0);
	return c;
}


double gsl_vector_complex_norm(gsl_vector_complex *v)
//calculate norm of vector v
{
	double norm_square = 0;
	for (mwSize i = 0; i<v->size; i++)
	{
		norm_square += gsl_complex_abs2(gsl_vector_complex_get(v, i));
	}
	return sqrt(norm_square);
}

double gsl_vector_complex_sum(gsl_vector_complex *v)
//summate absolute value of all element of v
{
	double sum = 0;
	for (mwSize i = 0; i<v->size; i++)
	{
		sum += gsl_complex_abs(gsl_vector_complex_get(v, i));
	}
	return sum;
}

/* Destructor */

bool input_data_free(c_data * input_data)
// free input_data
{
	gsl_vector_free(input_data->L_bound);
	gsl_vector_free(input_data->U_bound);
	delete(input_data);
	return true;
}